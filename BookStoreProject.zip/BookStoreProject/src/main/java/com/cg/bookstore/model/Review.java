package com.cg.bookstore.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;



@Entity
public class Review {

	@Id
	@Column(name = "review_id")
	private int reviewId;


	
	private String comment;

	private String headline;



	private int rating;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "review_time")
	private Date reviewTime;

	// bi-directional many-to-one association to Customer
	@ManyToOne
	@JoinColumn(name = "custId")
	private Customer customer1;

	// bi-directional many-to-one association to Book
	@ManyToOne
	@JoinColumn(name = "book_id")
	private Book book;

	
	public Review() {
	}


	public int getReviewId() {
		return reviewId;
	}


	public void setReviewId(int reviewId) {
		this.reviewId = reviewId;
	}


	


	public String getComment() {
		return comment;
	}


	public void setComment(String comment) {
		this.comment = comment;
	}


	public String getHeadline() {
		return headline;
	}


	public void setHeadline(String headline) {
		this.headline = headline;
	}


	public int getRating() {
		return rating;
	}


	public void setRating(int rating) {
		this.rating = rating;
	}


	public Date getReviewTime() {
		return reviewTime;
	}


	public void setReviewTime(Date reviewTime) {
		this.reviewTime = reviewTime;
	}


	public Customer getCustomer1() {
		return customer1;
	}


	public void setCustomer1(Customer customer1) {
		this.customer1 = customer1;
	}


	public Book getBook() {
		return book;
	}


	public void setBook(Book book) {
		this.book = book;
	}
	

}
