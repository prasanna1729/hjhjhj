package com.cg.bookstore.model;

import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


@Entity
public class Customer {
	@Id
	@Column(name="customer_id")
	private int customerId;

	private String address;

	private String city;

	private String country;

	private String email;

	private String fullname;

	private String password;

	private String phone;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="register_date")
	private Date registerDate;

	private String zipcode;

	//bi-directional many-to-one association to BookOrder
	@OneToMany(mappedBy="customer")
	private List<BookOrder> bookOrders;

	//bi-directional many-to-one association to Review
	@OneToMany(mappedBy="customer1")
	private List<Review> reviews1;

	//bi-directional many-to-one association to Review

	public Customer() {
	}

	public int getCustomerId() {
		return this.customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public String getAddress() {
		return this.address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getCity() {
		return this.city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getCountry() {
		return this.country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getEmail() {
		return this.email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getFullname() {
		return this.fullname;
	}

	public void setFullname(String fullname) {
		this.fullname = fullname;
	}


	public String getPassword() {
		return this.password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getPhone() {
		return this.phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public Date getRegisterDate() {
		return this.registerDate;
	}

	public void setRegisterDate(Date registerDate) {
		this.registerDate = registerDate;
	}

	public String getZipcode() {
		return this.zipcode;
	}

	public void setZipcode(String zipcode) {
		this.zipcode = zipcode;
	}

	public List<BookOrder> getBookOrders() {
		return this.bookOrders;
	}

	public void setBookOrders(List<BookOrder> bookOrders) {
		this.bookOrders = bookOrders;
	}

	public BookOrder addBookOrder(BookOrder bookOrder) {
		getBookOrders().add(bookOrder);
		bookOrder.setCustomer(this);

		return bookOrder;
	}

	public BookOrder removeBookOrder(BookOrder bookOrder) {
		getBookOrders().remove(bookOrder);
		bookOrder.setCustomer(null);

		return bookOrder;
	}

	public List<Review> getReviews1() {
		return this.reviews1;
	}

	public void setReviews1(List<Review> reviews1) {
		this.reviews1 = reviews1;
	}

	public Review addReviews1(Review reviews1) {
		getReviews1().add(reviews1);
		reviews1.setCustomer1(this);

		return reviews1;
	}

	public Review removeReviews1(Review reviews1) {
		getReviews1().remove(reviews1);
		reviews1.setCustomer1(null);

		return reviews1;
	}



}
